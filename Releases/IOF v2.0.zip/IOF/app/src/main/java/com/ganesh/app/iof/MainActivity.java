package com.ganesh.app.iof;
import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;
import org.tensorflow.lite.Interpreter;
import org.w3c.dom.Text;

import android.app.Activity;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

public class MainActivity extends AppCompatActivity {
    static {
        // to make sure that openCV lib are loaded
        if (!OpenCVLoader.initDebug()) {
            Log.e("OpenCV","Library not initialised");
        }else{
            Log.e("OpenCV","Library initialised");
        }
    }

    Interpreter tflite;
    /**
     * Dimensions of inputs.
     */
    private static final int DIM_BATCH_SIZE = 1;
    private static final int DIM_PIXEL_SIZE = 1;
    static final int DIM_IMG_SIZE_X = 28;
    static final int DIM_IMG_SIZE_Y = 28;
    private static final String TAG = "TfLiteDemo";
    private static final String LABEL_PATH = "labels.txt";
    private static final int RESULTS_TO_SHOW = 1;
    private List<String> labelList;
    public static ByteBuffer imgData = null;
    private float[][] labelProbArray = null;
    /* Preallocated buffers for storing image data in. */
    public static int[] intValues = new int[DIM_IMG_SIZE_X * DIM_IMG_SIZE_Y];
    public static final int IMAGE_MEAN = 128;
    public static final float IMAGE_STD = 128.0f;

    public String charPath, pagePath, fixedPath, originalPath, predictionPath;


    private PriorityQueue<Map.Entry<String, Float>> sortedLabels =
            new PriorityQueue<>(
                    RESULTS_TO_SHOW,
                    new Comparator<Map.Entry<String, Float>>() {
                        @Override
                        public int compare(Map.Entry<String, Float> o1, Map.Entry<String, Float> o2) {
                            return (o1.getValue()).compareTo(o2.getValue());
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initialize the tflite classifier
        try {
            ImageClassifier(this);
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("ImageClassifter", e.toString());
        }

        TextView testStarted = (TextView)findViewById(R.id.testStarted);
        testStarted.setText("Inferring");

        startProcess();

        TextView testDone = (TextView)findViewById(R.id.testDone);
        testDone.setText("Done");


    }

    private void startProcess(){
        String sdcardFolder = Environment.getExternalStorageDirectory().getAbsolutePath()+"/IOF/";  //*Don't* hardcode "/sdcard"
        charPath = sdcardFolder+"Characters";
        pagePath = sdcardFolder+"Pages";
        fixedPath = sdcardFolder+"Fixed";
        originalPath = sdcardFolder+"Original";
        predictionPath = sdcardFolder+"Predictions";;

        int turn=1;
        if(turn==0) charPrediction();
        else     pagePrediction();

      /* Prediction demo  */
//            // get image
//            ImageView imageView = (ImageView) findViewById(R.id.imageView);
//            imageView.setImageResource(R.drawable.cow);
//
//
//            Bitmap bitmap2 = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
//            Bitmap bitmap = ImageProcessor.getResizedBitmap(bitmap2, DIM_IMG_SIZE_X, DIM_IMG_SIZE_Y);
//            String textToShow = classifyFrame(bitmap);
//            Log.e("textToShow", textToShow);
//            bitmap.recycle();
    }

    private void pagePrediction() {
        File sdcard = Environment.getExternalStorageDirectory();  //*Don't* hardcode "/sdcard"
        File directory = new File (sdcard.getAbsolutePath() + "/IOF/Pages");
        String inputDir = directory.getAbsolutePath();
        ImageProcessor.contoursFromPages(inputDir);
        charPrediction();
    }

        private void charPrediction(){
        File sdcard = Environment.getExternalStorageDirectory();  //*Don't* hardcode "/sdcard"
        File directory = new File (sdcard.getAbsolutePath() + "/IOF/Characters");
        FileInputStream streamIn = null;
        try {
            int imgNo = 1;
            for (final File fileEntry : directory.listFiles()) {
                streamIn = new FileInputStream(fileEntry);
                Bitmap originalImage = BitmapFactory.decodeStream(streamIn); //This gets the image
                Bitmap resizedImage = ImageProcessor.getResizedBitmap(originalImage, DIM_IMG_SIZE_X, DIM_IMG_SIZE_Y);
                String prediction = classifyFrame(resizedImage);

                String outFileName = fileEntry.getName();  // eg 'name.jpg'
                int seperator = fileEntry.getName().indexOf('.');
                outFileName = outFileName.substring(0,seperator)+"-" +prediction+ outFileName.substring(seperator);  // eg 'name-prediction.jpg'
                String outFilePath =  sdcard.getAbsolutePath() + "/IOF/Predictions/"+outFileName;

                // convert to Mat to use imwrite()
                Mat origImgMat = new Mat(); Utils.bitmapToMat(originalImage,origImgMat);
                Imgcodecs.imwrite(outFilePath, origImgMat);
            }
            if (streamIn != null) { streamIn.close();
            }
        } catch (FileNotFoundException e) {
            Log.e("sdcard","file not found: "+e.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    public void inferButton (View view) {
        Toast.makeText(getApplicationContext(), "inferring",Toast.LENGTH_SHORT).show();

        String sd = Environment.getExternalStorageDirectory().getAbsolutePath()+"/IOF/";
        ImageProcessor.contoursFromPages(sd+"Pages/");

//        //Find the directory for the SD Card using the API
//        File sdcard = Environment.getExternalStorageDirectory();  //*Don't* hardcode "/sdcard"
//        File directory = new File (sdcard.getAbsolutePath() + "/IOF/Characters");  //Get the text file
//        FileInputStream streamIn = null;
//        try {
//            int imgNo=1;
//            for (final File fileEntry : directory.listFiles()) {
//                streamIn = new FileInputStream(fileEntry);
//                Bitmap bitmap2 = BitmapFactory.decodeStream(streamIn); //This gets the image
//
//                // make a copy of it to save fixed image to the disk
//                Mat imgCopy = new Mat();
//                Bitmap bmp32 = bitmap2.copy(Bitmap.Config.ARGB_8888, true);
//                Utils.bitmapToMat(bmp32, imgCopy);
//
//                Bitmap bitmap = ImageProcessor.getResizedBitmap(bitmap2, DIM_IMG_SIZE_X, DIM_IMG_SIZE_Y);
//                String prediction = imgNo+"-"+classifyFrame(bitmap);
//
//                String path = sdcard.getAbsolutePath() + "/IOF/fixed/"+prediction+".jpg";
//                Imgcodecs.imwrite(path, imgCopy);  imgNo++;
//                Log.e("fixed",prediction);
//                bitmap.recycle();
//            }
//            streamIn.close();
//        } catch (FileNotFoundException e) {
//            Log.e("sdcard","file not found: "+e.toString());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        Toast.makeText(this, "done predictions",Toast.LENGTH_SHORT).show();
    }


    /** Initializes an {@code ImageClassifier}. */
    private void ImageClassifier(Activity activity) throws IOException {
        try{
            tflite = new Interpreter(loadModelFile());
        }catch (Exception e){
            e.printStackTrace();
            Log.d(TAG, ""+e);
        }
        imgData =ByteBuffer.allocateDirect(
                4 * DIM_BATCH_SIZE * DIM_IMG_SIZE_X * DIM_IMG_SIZE_Y * DIM_PIXEL_SIZE);
        imgData.order(ByteOrder.nativeOrder());
        labelProbArray = new float[1][labelList.size()];
        //filterLabelProbArray = new float[FILTER_STAGES][labelList.size()];
        Log.d(TAG, "Created a Tensorflow Lite Image Classifier.");
    }

    public String classifyFrame(Bitmap bitmap){
        String Prediction="";
        if (tflite == null) {
            Log.e(TAG, "Image classifier has not been initialized; Skipped.");
            return "Uninitialized Classifier.";
        }
        ImageProcessor.convertBitmapToByteBuffer(bitmap);
        tflite.run(imgData, labelProbArray);

        // print the results
        float max=-1;  int idx=-1;
        for(int i=0;i<labelProbArray[0].length;i++){
            // Log.e("result", Float.toString(labelProbArray[0][i]));
            if(labelProbArray[0][i]>max) {
                max = labelProbArray[0][i];  idx=i;
            }
        }
        Prediction = ""+labelList.get(idx);
        return Prediction;
    }

    /* Memory-map the model file in Assets */
    private MappedByteBuffer loadModelFile() throws IOException{
        /* load labels */
        try {
            labelList = new ArrayList<String>();
            BufferedReader reader =
                    new BufferedReader(new InputStreamReader(this.getAssets().open(LABEL_PATH)));
            String line;
            while ((line = reader.readLine()) != null) {
                labelList.add(line);
            }
            reader.close();
        }catch (Exception e){
            Log.e("labels", ""+e);
        }

        // Open the model using an input stream, and memory map it to load
        AssetFileDescriptor fileDescriptor = this.getAssets().openFd("model.lite");
        FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel = inputStream.getChannel();
        long startOffset = fileDescriptor.getStartOffset();
        long declaredLength = fileDescriptor.getDeclaredLength();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
    }


}
