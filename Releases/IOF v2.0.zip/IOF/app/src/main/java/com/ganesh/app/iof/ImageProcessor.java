package com.ganesh.app.iof;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Environment;
import android.util.Log;

import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
/**
 * Created by Patra's Home on 07-01-2019.
 */

public class ImageProcessor {
    public void main(String[] args){
        Log.e("img main","why called me");
    }

    public static void contoursFromPages(String inputDirectory){
        File directory = new File (inputDirectory);
        FileInputStream streamIn = null;
        try {
            int imgNo=1;
            for (final File fileEntry : directory.listFiles()) {
                streamIn = new FileInputStream(fileEntry);
                Bitmap bitmapImg = BitmapFactory.decodeStream(streamIn); //This gets the image
                extractContours(bitmapImg);
                bitmapImg.recycle();
            }
            if (streamIn != null) {
                streamIn.close();
            }
        } catch (FileNotFoundException e) {
            Log.e("sdcard","file not found: "+e.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void extractContours(Bitmap inputImage) {
        Mat src = new Mat();
        Bitmap bmp32 = inputImage.copy(Bitmap.Config.ARGB_8888, true);
        Utils.bitmapToMat(bmp32, src);

        List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
        Mat hierarchy = new Mat();
        Imgproc.cvtColor(src, src, Imgproc.COLOR_BGR2GRAY);
        Core.normalize(src, src,0,255,Core.NORM_MINMAX);
        Imgproc.threshold(src, src, 128, 255, Imgproc.THRESH_BINARY|Imgproc.THRESH_OTSU);
        Imgproc.threshold(src, src, 0, 255, 1);

        Imgproc.findContours(src, contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_TC89_KCOS, new Point(0, 0));
        hierarchy.release();

        Log.e("cons",contours.size()+"");

        for ( int contourIdx=0; contourIdx < contours.size(); contourIdx++ )
        {   // Minimum size allowed for consideration
            MatOfPoint2f approxCurve = new MatOfPoint2f();
            MatOfPoint2f contour2f = new MatOfPoint2f( contours.get(contourIdx).toArray() );
            //Processing on mMOP2f1 which is in type MatOfPoint2f
            double approxDistance = Imgproc.arcLength(contour2f, true)*0.02;
            Imgproc.approxPolyDP(contour2f, approxCurve, approxDistance, true);

            //Convert back to MatOfPoint
            MatOfPoint points = new MatOfPoint( approxCurve.toArray() );

            // Get bounding rect of contour i.e ROI
            Rect rect = Imgproc.boundingRect(points);

            // display rect around contours
//            Imgproc.rectangle(src, new Point(rect.x, rect.y), new Point(rect.x + rect.width, rect.y + rect.height), new Scalar(255, 0, 0, 255), 1);

            // crop ROI
            Mat croppedContour = new Mat(src, rect);

            String outFileName =  Environment.getExternalStorageDirectory().getAbsolutePath()+
                                    "/IOF/Characters/"+contourIdx+".jpg";
            Imgcodecs.imwrite(outFileName, croppedContour);
        }
    }

    public static Bitmap getResizedBitmap(Bitmap bm, int newWidth, int newHeight) {
        int width = bm.getWidth();
        int height = bm.getHeight();
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        // CREATE A MATRIX FOR THE MANIPULATION
        Matrix matrix = new Matrix();
        // RESIZE THE BIT MAP
        matrix.postScale(scaleWidth, scaleHeight);

        // "RECREATE" THE NEW BITMAP
        Bitmap resizedBitmap = Bitmap.createBitmap(
                bm, 0, 0, width, height, matrix, false);
        //bm.recycle();
        return resizedBitmap;
    }

    /** Writes Image data into a {@code ByteBuffer}. */
    public static void convertBitmapToByteBuffer(Bitmap bitmap) {
        if (MainActivity.imgData == null) {
            return;
        }
        MainActivity.imgData.rewind();
        bitmap.getPixels(MainActivity.intValues, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());
        // Convert the image to floating point.
        int pixel = 0;
        for (int i = 0; i < MainActivity.DIM_IMG_SIZE_X; ++i) {
            for (int j = 0; j < MainActivity.DIM_IMG_SIZE_Y; ++j) {
                final int val = MainActivity.intValues[pixel++];
                MainActivity.imgData.putFloat((((val >> 16) & 0xFF)-MainActivity.IMAGE_MEAN)/MainActivity.IMAGE_STD);
                // imgData.putFloat((((val >> 8) & 0xFF)-IMAGE_MEAN)/IMAGE_STD);
                // imgData.putFloat((((val) & 0xFF)-IMAGE_MEAN)/IMAGE_STD);
            }
        }
    }

}
