package com.ganesh.app.iof;

import android.content.Intent;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class Options extends AppCompatActivity {
    public static String mode="";
    public static boolean clearChar;
    public static boolean clearPre;
    public static boolean clearInter;
    public static boolean clearFix;
    public static int houghThreshold;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);
    }

    public void runIOF(View view){
        RadioGroup rg = findViewById(R.id.modeRadioGroup);
        int rdId = rg.getCheckedRadioButtonId();
        RadioButton rd = findViewById(rdId);
        mode = rd.getText().toString();

        CheckBox ck = findViewById(R.id.Characters);
        clearChar = ck.isChecked();

        ck = findViewById(R.id.Predictions);
        clearPre = ck.isChecked();

        ck = findViewById(R.id.Intermediate);
        clearInter = ck.isChecked();

        ck = findViewById(R.id.Fixed);
        clearFix = ck.isChecked();

        try{
            houghThreshold = Integer.parseInt( ((EditText)findViewById(R.id.houghThreshold)).getText().toString() );
        }catch (Exception e){
            houghThreshold = 100;
        }

        Intent it = new Intent(this,Classifier.class);
        startActivity(it);
    }
}
