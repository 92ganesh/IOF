package com.ganesh.app.iof;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import java.util.ArrayList;
import java.util.List;
/**
 * Created by Patra's Home on 07-01-2019.
 */

public class ImageProcessor {
    static String currFile="";

    public void main(String[] args){

    }

    public static Mat fixVerticalOrientation(Mat inputImage) {
        long hor=0,ver=0;
        double horAvg=0,verAvg=0;

        // Declare the output variables
        Mat inputImageCopy = inputImage.clone();
        Mat src=new Mat(),dst = new Mat(), cdst = new Mat();
        Imgproc.cvtColor(inputImage, src, Imgproc.COLOR_BGR2GRAY);
        // Check if image is loaded fine
        if( src.empty() ) {
            System.out.println("Error opening image!");
            System.exit(-1);
        }
        // Edge detection
        Imgproc.Canny(src, dst, 50, 200, 3, false);
        // Copy edges to the images that will display the results in BGR
        Imgproc.cvtColor(dst, cdst, Imgproc.COLOR_GRAY2BGR);
        // Standard Hough Line Transform
        Mat lines = new Mat(); // will hold the results of the detection
        Imgproc.HoughLines(dst, lines, 1, Math.PI/180,Options.houghThreshold); // runs the actual detection
        // Draw the lines
        for (int x = 0; x < lines.rows(); x++) {
            double rho = lines.get(x, 0)[0],
                    theta = lines.get(x, 0)[1];
            double a = Math.cos(theta), b = Math.sin(theta);
            double x0 = a*rho, y0 = b*rho;
            Point pt1 = new Point(Math.round(x0 + 1000*(-b)), Math.round(y0 + 1000*(a)));
            Point pt2 = new Point(Math.round(x0 - 1000*(-b)), Math.round(y0 - 1000*(a)));

            //to show lines on img for debugging
            Imgproc.line(inputImageCopy, pt1, pt2, new Scalar(0, 0, 255), 1, Imgproc.LINE_AA, 0);

            double dx = Math.abs(pt2.x) - pt1.x;  double dy = Math.abs(pt2.y - pt1.y);
            if(Math.abs(dy)>Math.abs(dx)) {
                ver++;
                if(Math.abs(dx)==0) {  verAvg+=0;
                }else {
                    double slope= ((1.0*dy)/dx);
                    double temp = Math.abs( (90-Math.toDegrees( Math.atan(slope)) ));
                    verAvg+=temp ;
                }
            }else {
                hor++;
                double slope= ((1.0*dy)/dx);
                horAvg+= Math.toDegrees( Math.atan(slope) );
            }
        }

        int rotationAngle=0;
        String closerPosition;  // closer Position and angle with it. For debugging
        if(ver>hor) {
            double verAng = (1.0*verAvg)/ver;
            rotationAngle=90-(int)verAng;
            closerPosition = "Vertical  "+(int)verAng;
        }else {
            double horAng = (1.0*horAvg)/hor;
            rotationAngle=(int)horAng;
            closerPosition ="Horizontal  "+(int)horAng;
        }
        Mat fixedImage = rotateImage(inputImage,-rotationAngle);
        Imgcodecs.imwrite(Classifier.intermediatePath+"/"+currFile, inputImageCopy);

        Classifier.fileNames+=currFile+"\n\n";
        Classifier.filesInfo+=closerPosition+"\n\n";
        return fixedImage;
    }

    public static Mat rotateImage(Mat src, int angleDegrees) {
         //Creating the transformation matrix M
        /** Imgproc.getRotationMatrix2D(center, angle, 1.0); //1.0 means 100 % scale
         */
        Mat rotationMatrix = Imgproc.getRotationMatrix2D(new Point(src.cols()/2, src.rows()/2 ), angleDegrees,1);
        //Rotating the given image
        int size = src.rows();  if(size<src.cols()) { size=src.cols(); }

        Mat dst = new Mat();
        Imgproc.warpAffine(src, dst,rotationMatrix, new Size(src.cols(),src.rows() ));
        return dst;
    }

    public static void extractContours(Mat src) {
        List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
        Mat hierarchy = new Mat();
        Imgproc.cvtColor(src, src, Imgproc.COLOR_BGR2GRAY);
        Core.normalize(src, src,0,255,Core.NORM_MINMAX);
        Imgproc.threshold(src, src, 128, 255, Imgproc.THRESH_BINARY|Imgproc.THRESH_OTSU);
        Imgproc.threshold(src, src, 0, 255, 1);

        Imgproc.findContours(src, contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_TC89_KCOS, new Point(0, 0));
        hierarchy.release();

        for ( int contourIdx=0; contourIdx < contours.size(); contourIdx++ )
        {   // Minimum size allowed for consideration
            MatOfPoint2f approxCurve = new MatOfPoint2f();
            MatOfPoint2f contour2f = new MatOfPoint2f( contours.get(contourIdx).toArray() );
            //Processing on mMOP2f1 which is in type MatOfPoint2f
            double approxDistance = Imgproc.arcLength(contour2f, true)*0.02;
            Imgproc.approxPolyDP(contour2f, approxCurve, approxDistance, true);

            //Convert back to MatOfPoint
            MatOfPoint points = new MatOfPoint( approxCurve.toArray() );

            // Get bounding rect of contour i.e ROI
            Rect rect = Imgproc.boundingRect(points);

            // display rect around contours
//            Imgproc.rectangle(src, new Point(rect.x, rect.y), new Point(rect.x + rect.width, rect.y + rect.height), new Scalar(255, 0, 0, 255), 1);

            // crop ROI
            Mat croppedContour = new Mat(src, rect);

            String outFileName =  Classifier.charPath+contourIdx+".jpg";
            Imgcodecs.imwrite(outFileName, croppedContour);
        }
    }

    public static Bitmap getResizedBitmap(Bitmap bm, int newWidth, int newHeight) {
        int width = bm.getWidth();
        int height = bm.getHeight();
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        // CREATE A MATRIX FOR THE MANIPULATION
        Matrix matrix = new Matrix();
        // RESIZE THE BIT MAP
        matrix.postScale(scaleWidth, scaleHeight);

        // "RECREATE" THE NEW BITMAP
        Bitmap resizedBitmap = Bitmap.createBitmap(
                bm, 0, 0, width, height, matrix, false);
        //bm.recycle();
        return resizedBitmap;
    }

    /** Writes Image data into a {@code ByteBuffer}. */
    public static void convertBitmapToByteBuffer(Bitmap bitmap) {
        if (Classifier.imgData == null) {
            return;
        }
        Classifier.imgData.rewind();
        bitmap.getPixels(Classifier.intValues, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());
        // Convert the image to floating point.
        int pixel = 0;
        for (int i = 0; i < Classifier.DIM_IMG_SIZE_X; ++i) {
            for (int j = 0; j < Classifier.DIM_IMG_SIZE_Y; ++j) {
                final int val = Classifier.intValues[pixel++];
                Classifier.imgData.putFloat((((val >> 16) & 0xFF)- Classifier.IMAGE_MEAN)/ Classifier.IMAGE_STD);
                // imgData.putFloat((((val >> 8) & 0xFF)-IMAGE_MEAN)/IMAGE_STD);
                // imgData.putFloat((((val) & 0xFF)-IMAGE_MEAN)/IMAGE_STD);
            }
        }
    }



}
