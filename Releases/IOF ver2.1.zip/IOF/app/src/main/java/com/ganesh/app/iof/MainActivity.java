package com.ganesh.app.iof;
import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;
import org.tensorflow.lite.Interpreter;
import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

public class MainActivity extends AppCompatActivity {
    static {
        // to make sure that openCV lib are loaded
        if (!OpenCVLoader.initDebug()) {
            Log.e("OpenCV","Library not initialised");
        }else{
            Log.e("OpenCV","Library initialised");
        }
    }

    Interpreter tflite;
    /**
     * Dimensions of inputs.
     */
    // Permissions
    private final int CAMERA_PERMISSION_CODE=100;
    private final int READ_PERMISSION_CODE=101;
    private final int WRITE_PERMISSION_CODE=102;
    private final int TOTAL_PERMISSION_REQUIRED=3;
    private int TOTAL_PERMISSION_GRANTED=0;

    private static final int DIM_BATCH_SIZE = 1;
    private static final int DIM_PIXEL_SIZE = 1;
    static final int DIM_IMG_SIZE_X = 28;
    static final int DIM_IMG_SIZE_Y = 28;
    private static final String TAG = "TfLiteDemo";
    private static final String LABEL_PATH = "labels.txt";
    private static final int RESULTS_TO_SHOW = 1;
    private static final int NUM_CLASSES = 2;
    private List<String> labelList;
    public static ByteBuffer imgData = null;
    private float[][] labelProbArray = null;
    /* Preallocated buffers for storing image data in. */
    public static int[] intValues = new int[DIM_IMG_SIZE_X * DIM_IMG_SIZE_Y];
    public static final int IMAGE_MEAN = 128;
    public static final float IMAGE_STD = 128.0f;
    public static String charPath, pagePath, fixedPath, intermediatePath, predictionPath;
    public static String fileNames="",filesInfo="";

    private PriorityQueue<Map.Entry<String, Float>> sortedLabels =
            new PriorityQueue<>(
                    RESULTS_TO_SHOW,
                    new Comparator<Map.Entry<String, Float>>() {
                        @Override
                        public int compare(Map.Entry<String, Float> o1, Map.Entry<String, Float> o2) {
                            return (o1.getValue()).compareTo(o2.getValue());
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initialize the tflite classifier
        try {
            ImageClassifier(this);
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("ImageClassifter", e.toString());
        }

        if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},WRITE_PERMISSION_CODE);
        }else{
            startProcess();
        }

    }

    private void startProcess(){
        TextView testStarted = (TextView)findViewById(R.id.status);
        testStarted.setText("Inferring");

        String sdcardFolder = Environment.getExternalStorageDirectory().getAbsolutePath()+"/IOF/";  //*Don't* hardcode "/sdcard"
        charPath = sdcardFolder+"Characters/";
        pagePath = sdcardFolder+"Pages/";
        fixedPath = sdcardFolder+"Fixed/";
        intermediatePath = sdcardFolder+"Intermediate/";
        predictionPath = sdcardFolder+"Predictions/";;

        // create dir if does not exist
        new File(sdcardFolder).mkdir();
        new File(charPath).mkdir();
        new File(pagePath).mkdir();
        new File(fixedPath).mkdir();
        new File(intermediatePath).mkdir();
        new File(predictionPath).mkdir();


        cleanDirectories();

        int turn=1;
        if(turn==0) charPrediction(new int[NUM_CLASSES]);
        else     pagePrediction();

      /* Prediction demo  */
//            // get image
//            ImageView imageView = (ImageView) findViewById(R.id.imageView);
//            imageView.setImageResource(R.drawable.cow);
//
//
//            Bitmap bitmap2 = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
//            Bitmap bitmap = ImageProcessor.getResizedBitmap(bitmap2, DIM_IMG_SIZE_X, DIM_IMG_SIZE_Y);
//            String textToShow = classifyFrame(bitmap);
//            Log.e("textToShow", textToShow);
//            bitmap.recycle();

        testStarted.setText("Done");

        TextView filesText = (TextView)findViewById(R.id.fileNamesList);
        filesText.setText(fileNames);
        TextView filesInfoText = (TextView)findViewById(R.id.orientationList);
        filesInfoText.setText(filesInfo);
    }

    private void cleanDirectories(){
        // clean pre data
        File dir = new File(charPath);
        for(File fileEntry:dir.listFiles()) {
            fileEntry.delete();
        }
        dir = new File(predictionPath);
        for(File fileEntry:dir.listFiles()) {
            fileEntry.delete();
        }
    }


    private void pagePrediction() {
        int[] PredictionCount;
        File directory = new File (pagePath);
        FileInputStream streamIn = null;
        try {

            for (final File fileEntry : directory.listFiles()) {
                cleanDirectories();
                ImageProcessor.currFile = fileEntry.getName();
                streamIn = new FileInputStream(fileEntry);
                Bitmap bitmapImg = BitmapFactory.decodeStream(streamIn); //This gets the image
                Mat inputImg = new Mat();
                Bitmap bmp32 = bitmapImg.copy(Bitmap.Config.ARGB_8888, true);
                Utils.bitmapToMat(bmp32, inputImg);
                Mat newImg = ImageProcessor.fixVerticalOrientation(inputImg);  // now the image is either at 0° or 180°
                Mat newImgCopy = newImg.clone();
                ImageProcessor.extractContours(newImg);
                bitmapImg.recycle();

                PredictionCount = new int[NUM_CLASSES];
                charPrediction(PredictionCount);

                if(PredictionCount[0]<PredictionCount[1]){
                    Mat finalRotation = ImageProcessor.rotateImage(newImgCopy,180);
                    Imgcodecs.imwrite(fixedPath+"/"+ImageProcessor.currFile, finalRotation);
                }else{
                    Imgcodecs.imwrite(fixedPath+"/"+ImageProcessor.currFile, newImgCopy);
                }
            }
            if (streamIn != null) { streamIn.close();
            }
        } catch (FileNotFoundException e) {
            Log.e("sdcard","file not found: "+e.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void charPrediction(int[] PredictionCount){
        File directory = new File(charPath);
        FileInputStream streamIn = null;
        try {
             for (final File fileEntry : directory.listFiles()) {
                streamIn = new FileInputStream(fileEntry);
                Bitmap originalImage = BitmapFactory.decodeStream(streamIn); //This gets the image
                Bitmap resizedImage = ImageProcessor.getResizedBitmap(originalImage, DIM_IMG_SIZE_X, DIM_IMG_SIZE_Y);
                String prediction = classifyFrame(resizedImage);
                try{ PredictionCount[Integer.parseInt(prediction)]++;
                }catch(Exception e){
                    Log.e("MainActivity",e.toString());
                    finish();
                }
                // save predicted image
                String outFileName = fileEntry.getName();  // eg 'name.jpg'
                int seperator = fileEntry.getName().indexOf('.');
                outFileName = prediction+"-" +outFileName.substring(0,seperator)+ outFileName.substring(seperator);  // eg 'name-prediction.jpg'
                String outFilePath =  predictionPath+outFileName;

                // convert to Mat to use imwrite()
                Mat origImgMat = new Mat(); Utils.bitmapToMat(originalImage,origImgMat);
                Imgcodecs.imwrite(outFilePath, origImgMat);
            }

            if (streamIn != null) { streamIn.close();
            }
        } catch (FileNotFoundException e) {
            Log.e("sdcard","file not found: "+e.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    /** Initializes an {@code ImageClassifier}. */
    private void ImageClassifier(Activity activity) throws IOException {
        try{
            tflite = new Interpreter(loadModelFile());
        }catch (Exception e){
            e.printStackTrace();
            Log.d(TAG, ""+e);
        }
        imgData =ByteBuffer.allocateDirect(
                4 * DIM_BATCH_SIZE * DIM_IMG_SIZE_X * DIM_IMG_SIZE_Y * DIM_PIXEL_SIZE);
        imgData.order(ByteOrder.nativeOrder());
        labelProbArray = new float[1][labelList.size()];
        //filterLabelProbArray = new float[FILTER_STAGES][labelList.size()];
        Log.d(TAG, "Created a Tensorflow Lite Image Classifier.");
    }

    public String classifyFrame(Bitmap bitmap){
        String Prediction="";
        if (tflite == null) {
            Log.e(TAG, "Image classifier has not been initialized; Skipped.");
            return "Uninitialized Classifier.";
        }
        ImageProcessor.convertBitmapToByteBuffer(bitmap);
        tflite.run(imgData, labelProbArray);

        // print the results
        float max=-1;  int idx=-1;
        for(int i=0;i<labelProbArray[0].length;i++){
            // Log.e("result", Float.toString(labelProbArray[0][i]));
            if(labelProbArray[0][i]>max) {
                max = labelProbArray[0][i];  idx=i;
            }
        }
        Prediction = ""+labelList.get(idx);
        return Prediction;
    }

    /* Memory-map the model file in Assets */
    private MappedByteBuffer loadModelFile() throws IOException{
        /* load labels */
        try {
            labelList = new ArrayList<String>();
            BufferedReader reader =
                    new BufferedReader(new InputStreamReader(this.getAssets().open(LABEL_PATH)));
            String line;
            while ((line = reader.readLine()) != null) {
                labelList.add(line);
            }
            reader.close();
        }catch (Exception e){
            Log.e("labels", ""+e);
        }

        // Open the model using an input stream, and memory map it to load
        AssetFileDescriptor fileDescriptor = this.getAssets().openFd("model.lite");
        FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel = inputStream.getChannel();
        long startOffset = fileDescriptor.getStartOffset();
        long declaredLength = fileDescriptor.getDeclaredLength();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case WRITE_PERMISSION_CODE: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startProcess();
                } else {
                    Toast.makeText(this,"Write permission denied",Toast.LENGTH_LONG).show();
                }
                break;
            }
        }
    }
}
